import React, { useEffect, useRef, useState } from "react";
import ItemTarea from "./ItemTarea";
import { v4 as uuid } from 'uuid';


function ListaTareas() {

    const [tareas, setTareas] = useState([]);

    const tareaRef = useRef();
    const tituloRef = useRef();
    const impRef = useRef();

  
    const KEY = 'tareas-app-tareas';

   
    useEffect(()=>{
        const misTareas = JSON.parse(localStorage.getItem(KEY));
        if (misTareas){
            setTareas(misTareas);
        }
    }, []);

    
    useEffect(()=>{
        const json = JSON.stringify(tareas);
        console.log(json);
        localStorage.setItem(KEY, json);
    }, [tareas]);

    const agregarTarea = () => {
        const tarea = tareaRef.current.value;
        const titulo = tituloRef.current.value;
        const imp = impRef.current.checked;
        console.log(tarea);

        if (tarea === '') return;

        setTareas( (prev) => {
            const nuevaTarea = {
                id:uuid(),
                tarea:tarea,
                titulo:titulo,
                imp:imp
            }
            tareaRef.current.value = "";
            tituloRef.current.value = "";
            return [...prev, nuevaTarea];
        })
    }

    return(
        <>
        <h2>AGREGAR NOTAS</h2>
        <div className="input-group my-4">
      
            <input ref={tituloRef} className="form-control" placeholder="Ingrese un titulo"></input>
            <input ref={tareaRef} className="form-control" placeholder="Ingrese una tarea"></input>
            <input ref={impRef} type="checkbox"></input> 
            <span className="ms-1">Importante!!!</span>
            <button onClick={agregarTarea} className="btn btn-primary ms-2">Agregar</button>
        </div >

        <ul>
  {tareas.map((t) => (
                <ItemTarea key={t.id} tarea={t.tarea } titulo={t.titulo} imp={t.imp}></ItemTarea>
            ))}

</ul>
       
            
        
        </>
    );
}

export default ListaTareas;