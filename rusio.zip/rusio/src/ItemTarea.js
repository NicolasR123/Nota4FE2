import React from "react";
import "./App.css"
import "./assets/cont.css"



function ItemTarea(prop) {

    if (prop.imp){
        return(
          <li style={{background:"red"}}> <div class="bottom" style={{background:"red"}}> <h3><strong>{prop.titulo}</strong></h3> </div> 
          
      
          
            <p >{prop.tarea}</p>
          
     
        </li>
        );

    }else{return(
      <li> <div class="bottom"><h3><strong>{prop.titulo}</strong></h3> </div> 
          
      
          
            <p  >{prop.tarea}</p>
          
     
        </li>
    );}

    
}

export default ItemTarea;